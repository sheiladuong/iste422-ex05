external components used:
ChakraUI from https://www.chakra-ui.com/
RadixUI from https://www.radix-ui.com/
MUI from https://mui.com/material-ui/